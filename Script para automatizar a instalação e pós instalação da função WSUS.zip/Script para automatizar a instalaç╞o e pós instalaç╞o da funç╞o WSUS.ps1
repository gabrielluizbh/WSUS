﻿# Script para automatização da instalação e pós instalação da função WSUS. - Gabriel Luiz - www.gabrielluiz.com


Get-WindowsFeature –Name UpdateServices* # Verifica se a função WSUS já foi instalado no servidor.

Install-WindowsFeature -ComputerName WSUS3.contoso.local -Name Updateservices,UpdateServices-WidDB,UpdateServices-services  -IncludeManagementTools # Instala a Função WSUS no servidor. Necessário reiniciar o servidor, após a instalação.

Restart-Computer -Force # Reinicie o servidor com este comando. 


# Agora vamos fazer a pós instalação, para isso navege até a pasta C:\Program Files\Update Services\Tools, utilizando o comando "cd" é o nome do diretório, Exemplo: cd c:\Program Files, utilize o comando "dir" para listar os diretórios.

cd '.\Program Files\Update Services\Tools\' # Comando para ir direto para o diretório.


# Execute o executavel WsusUtil.exe, ele vai executar a pós instalação.


8 .\WsusUtil.exe # Esse comando executa o programa de ira executar a configuração da pós instalação.


.\Wsusutil.exe postinstall CONTENT_DIR=D:\WSUS-Dados # Execute postinstall para um servidor WSUS usando a função WID para armazenar os arquivos de instalação baixados no diretório D:\WSUS-Dados.


get-website # Verifique se a pós instalação está correta.


Invoke-BpaModel -ModelId Microsoft/Windows/UpdateServices #‎ Inspecionar o estado de instalação do WSUS‎.


Get-BpaResult -ModelId Microsoft/Windows/UpdateServices | Select Title,Severity,Compliance | Format-List # verificar o Best Practices Analyzer (As melhores práticas da função WSUS).


